<?php
function pembagian($angka_1, $angka_2) {
    $i = 0;
  
    while ($angka_1 >= $angka_2) {
        $angka_1 -= $angka_2;
        $i++;
    }
  
    return $i;
}

$angka_1 = 7;
$angka_2 = 2;
$result = pembagian($angka_1, $angka_2);
echo "Output: " . $result . "<br>";



$angka_1 = 8;
$angka_2 = 4;
$result = pembagian($angka_1, $angka_2);
echo "Output: " . $result;


?>